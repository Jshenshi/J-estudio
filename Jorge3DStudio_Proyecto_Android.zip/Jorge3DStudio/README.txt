JORGE 3D STUDIO - PROYECTO ANDROID INICIAL

Incluye una interfaz Android inicial (WebView) y un flujo automatizado para compilar un APK de prueba usando GitHub Actions.

IMPORTANTE:
Esta es una primera versión de interfaz, NO un generador 3D con IA funcional todavía.
La pantalla permite escribir una descripción o seleccionar una imagen, pero todavía no crea modelos reales.
Para generar modelos reales con IA hay que conectar un proveedor/servidor de generación. Sus cuotas y precios externos siguen aplicando; no se eliminan límites de terceros.

COMPILAR APK EN LA NUBE (requiere una cuenta de GitHub):
1. Descarga y descomprime este ZIP.
2. En GitHub, crea un repositorio nuevo vacío.
3. Sube todos los archivos y carpetas del proyecto, incluida la carpeta oculta .github/workflows.
4. Abre la pestaña Actions del repositorio.
5. Selecciona "Build Android APK" y pulsa "Run workflow" (o espera a que termine la compilación automática al subir a main).
6. Cuando termine correctamente, abre la ejecución y descarga el artifact "Jorge-3D-Studio-debug-apk".
7. Dentro encontrarás app-debug.apk. Es un APK de depuración para pruebas.

COMPILACIÓN LOCAL:
Abre la carpeta del proyecto en Android Studio, sincroniza Gradle y ejecuta Build > Build Bundle(s) / APK(s) > Build APK(s).

Requisitos del proyecto: Android SDK 35, Java 17 y Gradle 8.9.
